package com.e_voting.registration;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;

@WebServlet("/VotesServlet")
public class VotesServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Map<String, Integer> partyVotes = new HashMap<>();

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/E_voting?useSSL=false", "root", "Rajiv@2023");

            String query = "SELECT party_name, COUNT(*) as vote_count FROM votes GROUP BY party_name";
            ps = con.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                partyVotes.put(rs.getString("party_name"), rs.getInt("vote_count"));
            }

            request.setAttribute("partyVotes", partyVotes);
            request.getRequestDispatcher("adminPanel.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) try { rs.close(); } catch (SQLException ignored) {}
            if (ps != null) try { ps.close(); } catch (SQLException ignored) {}
            if (con != null) try { con.close(); } catch (SQLException ignored) {}
        }
    }
}
